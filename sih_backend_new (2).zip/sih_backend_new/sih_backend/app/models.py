from sqlalchemy import Column, Integer, String
from .database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)

    name = Column(String(100), nullable=False)

    email = Column(
        String(255),
        unique=True,
        index=True,
        nullable=False
    )

    password_hash = Column(String(255), nullable=False)

    role = Column(String(20), nullable=False)


class Case(Base):
    __tablename__ = "cases"

    id = Column(Integer, primary_key=True, index=True)

    case_id = Column(String(50), unique=True, index=True, nullable=False)

    risk_level = Column(String(20), nullable=False)

    assigned_counsellor = Column(String(100), nullable=False)

    last_assessment = Column(String(50), nullable=False)

    intervention_status = Column(String(100), nullable=False)