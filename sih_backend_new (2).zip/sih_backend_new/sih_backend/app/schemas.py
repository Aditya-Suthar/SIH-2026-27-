from pydantic import BaseModel, EmailStr


class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str
    role: str


class CaseOut(BaseModel):
    caseId: str
    riskLevel: str
    assignedCounsellor: str
    lastAssessment: str
    interventionStatus: str

    class Config:
        from_attributes = True