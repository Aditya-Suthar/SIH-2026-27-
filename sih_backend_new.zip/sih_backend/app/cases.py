from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .database import get_db
from .auth import get_current_user
from . import models, schemas

router = APIRouter(prefix="/api")


@router.get("/cases", response_model=List[schemas.CaseOut])
def get_cases(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    cases = db.query(models.Case).all()

    return [
        schemas.CaseOut(
            caseId=c.case_id,
            riskLevel=c.risk_level,
            assignedCounsellor=c.assigned_counsellor,
            lastAssessment=c.last_assessment,
            interventionStatus=c.intervention_status,
        )
        for c in cases
    ]
